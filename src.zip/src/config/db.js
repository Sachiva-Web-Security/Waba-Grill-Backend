const mysql = require("mysql2");

const db = mysql.createPool({
  host: "127.0.0.1",
  user: "root",
  password: "", // XAMPP default
  database: "wavagrill", // 🔥 Yaha apna DB name daalo
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

// Test connection
db.getConnection((err, connection) => {
  if (err) {
    console.error("❌ MySQL pool connection failed:", err);
  } else {
    console.log("✅ MySQL pool connected successfully");
    connection.release();
  }
});

module.exports = db.promise();
